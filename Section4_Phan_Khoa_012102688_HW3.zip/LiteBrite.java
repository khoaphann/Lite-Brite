/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//*package litebrite;


import javafx.application.Application;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.scene.shape.StrokeType;

/**
 *
 * @Khoa Phan
 */
public class LiteBrite extends Application
{

	final int rows = 50;
    final int columns = 50;
    static Color pickedColor;
    static GridPane grid = new GridPane();

    @Override
    public void start(final Stage stage) throws Exception
    {

        stage.setTitle("Enjoy your game");

        VBox container = new VBox(10); // container contains subcontainer and the grid vertically
        container.getStyleClass().add("container");

		grid = drawGridPane(); // create gride

		HBox subcontainer = new HBox(10); // subcontainer contain color picker and reset button
		subcontainer.getStyleClass().add("subcontainer");

        ColorPicker colorPicker = new ColorPicker(Color.WHITE); // declare a color picker

		Pane gcon = new Pane(); //note a pane
		gcon.getChildren().add(grid);

        pickedColor = colorPicker.getValue(); // default color picker as white
        colorPicker.setOnAction(e ->
        {
            pickedColor = colorPicker.getValue();
        });

        Button resetButton = new Button("Reset");
        resetButton.setOnAction(e ->
        {
            grid = drawGridPane(); // draw a drid pane
        });

		subcontainer.getChildren().addAll(colorPicker, resetButton); // add color pick and reset button to subcontainer
        container.getChildren().addAll(subcontainer, gcon); // add subcontainer and the grid to container

        Scene scene = new Scene(container,(columns * 10) - 10, (rows * 10) + 40); // add container to a scene
        scene.getStylesheets().add(LiteBrite.class.getResource("resources/game.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }



       public GridPane drawGridPane()
       {
		   grid.getStyleClass().add("game-grid");
        for(int i = 0; i < columns; i++)
        {
            ColumnConstraints column = new ColumnConstraints(10);
            grid.getColumnConstraints().add(column);
        }

        for(int i = 0; i < rows; i++)
        {
            RowConstraints row = new RowConstraints(10);
            grid.getRowConstraints().add(row);
        }

        for (int i = 0; i < columns; i++)
        {
            for (int j = 0; j < rows; j++)
            {
                Pane pane = new Pane();
                pane.setOnMouseReleased(e ->  {
                    pane.getChildren().add(Anims.getAtoms(1));
                    pane.setOnMouseReleased(null);
                });
                pane.getStyleClass().add("game-grid-cell");
                grid.add(pane, i, j);

            }
        }
        return grid;
       }

 public static class Anims {
        public static Node getAtoms(final int number) {
					Rectangle rectangle = new Rectangle(10,10); // add a rectangle cell
					rectangle.setStroke(Color.WHITE); // default color of the border of rectangle as white
					rectangle.setStrokeWidth(0.5); // set the broder width
					rectangle.setStrokeType(StrokeType.INSIDE);
					rectangle.setFill(pickedColor); // add picked color to the reactangle

					rectangle.setOnMouseReleased( e -> {
						if (rectangle.getFill() != Color.BLACK) // click to make the rectangle turn to black if the rectangle is not black
							rectangle.setFill(Color.BLACK) ;

						else
							rectangle.setFill(pickedColor); // click to color picked color to the rectangle
					});
            return rectangle;

        }
    }
    public static void main(final String[] arguments)
    {
        Application.launch(arguments);
    }

}

