User: 012102688 (Phan, Khoa)

When you clicked on the colored cell, it would the the color of the cell to black.